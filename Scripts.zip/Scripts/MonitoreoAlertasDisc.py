import paramiko
import requests

# Configuración de acceso al VPS
SSH_USER = "usuario"  # Nombre de usuario del VPS (modificado para seguridad)
SSH_PASSWORD = "contraseña"  # Contraseña del VPS (modificada para seguridad)
CASSANDRA_HOST = "IP_DEL_SERVIDOR_CASSANDRA"  # IP del servidor Cassandra (modificada para seguridad)

# URL del webhook de Discord
DISCORD_WEBHOOK_URL = "URL_DEL_WEBHOOK_DE_DISCORD"  # URL del webhook de Discord (modificada para seguridad)

# Función para ejecutar un comando remoto usando SSH
def execute_remote_command(command):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(CASSANDRA_HOST, username=SSH_USER, password=SSH_PASSWORD)
        stdin, stdout, stderr = ssh.exec_command(command)
        output = stdout.read().decode().strip()
        error = stderr.read().decode().strip()
        ssh.close()
        if error:
            raise Exception(f"Error remoto: {error}")
        return output
    except Exception as e:
        return f"Error: {str(e)}"

# Función para obtener el estado de los nodos con nodetool
def get_cassandra_status():
    command = "nodetool status"
    return execute_remote_command(command)

# Función para analizar el estado de los nodos
def analyze_status(status_output):
    nodes = []
    lines = status_output.splitlines()
    for line in lines:
        # Saltar encabezados y separadores
        if line.startswith("Datacenter") or line.startswith("Status") or line.startswith("--"):
            continue

        # Dividir línea respetando espacios y asignar correctamente los campos
        parts = line.split()
        if len(parts) >= 8:
            nodes.append({
                "estado": parts[0],               # Estado del nodo
                "ip": parts[1],                   # Dirección IP
                "load": f"{parts[2]} {parts[3]}", # Carga (con unidades)
                "tokens": parts[4],               # Número de tokens
                "owns": parts[5],                 # Porcentaje de propiedad
                "host_id": parts[6],              # Host ID
                "rack": parts[7],                 # Rack
            })
    return nodes

# Función para generar mensaje de notificación
def generate_message(nodes):
    if not nodes:
        return "⚠️ No se pudieron obtener datos sobre los nodos de Cassandra."

    header = "📊 **Estado de los Nodos de Cassandra** 📊\n\n"
    details = ""
    alert = False

    for node in nodes:
        if node["estado"] != "UN":
            alert = True
        details += (
            f"- **Nodo:** {node['ip']}\n"
            f"  - Estado: `{node['estado']}`\n"
            f"  - Load: {node['load']}\n"
            f"  - Tokens: {node['tokens']}\n"
            f"  - Owns: {node['owns']}\n"
            f"  - Host ID: {node['host_id']}\n"
            f"  - Rack: {node['rack']}\n\n"
        )

    summary = (
        "⚠️ **Problemas detectados:** Algunos nodos no están en estado `UN`. ⚠️\n\n"
        if alert
        else "✅ **Todos los nodos están activos y funcionando correctamente.** ✅\n\n"
    )

    return header + summary + details

# Función para enviar notificación a Discord
def send_discord_notification(content):
    try:
        data = {"content": content}
        headers = {"Content-Type": "application/json"}
        response = requests.post(DISCORD_WEBHOOK_URL, json=data, headers=headers)
        if response.status_code == 204:
            print("✅ Notificación enviada a Discord con éxito.")
        else:
            print(f"⚠️ Error al enviar notificación: {response.status_code}")
    except Exception as e:
        print(f"⚠️ Error al enviar notificación: {str(e)}")

# Función principal para monitorear Cassandra
def monitor_cassandra():
    print("🔍 Verificando estado de Cassandra...")
    status_output = get_cassandra_status()
    if "Error" in status_output:
        print(f"⚠️ {status_output}")
        send_discord_notification(f"⚠️ {status_output}")
        return

    nodes = analyze_status(status_output)
    message = generate_message(nodes)
    send_discord_notification(message)
    print("📤 Mensaje enviado:\n", message)

    # Detener si todos los nodos están en estado `UN`
    if all(node["estado"] == "UN" for node in nodes):
        print("✅ Todos los nodos están en estado `UN`. Finalizando monitoreo.")
        return True
    return False

# Ejecutar monitoreo una sola vez
if __name__ == "__main__":
    if not monitor_cassandra():
        print("⚠️ Monitoreo no finalizado. Verifica los problemas reportados.")
