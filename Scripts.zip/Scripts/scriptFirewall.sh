#!/bin/bash

# Crear la tabla y las cadenas
sudo nft add table inet filter
sudo nft add chain inet filter input { type filter hook input priority 0 \; policy drop \; }
sudo nft add chain inet filter forward { type filter hook forward priority 0 \; policy drop \; }
sudo nft add chain inet filter output { type filter hook output priority 0 \; policy accept \; }

# Permitir tráfico en la interfaz local
sudo nft add rule inet filter input iif lo accept
sudo nft add rule inet filter output oif lo accept

# Permitir tráfico para puertos esenciales (SSH, HTTP, HTTPS, y otros)
sudo nft add rule inet filter input tcp dport 22 accept  # SSH
sudo nft add rule inet filter input tcp dport 80 accept  # HTTP
sudo nft add rule inet filter input tcp dport 8080 accept  # HTTP alternativo
sudo nft add rule inet filter input tcp dport 3000 accept  # Usado por aplicaciones
sudo nft add rule inet filter input tcp dport 9000 accept  # Usado por herramientas de monitorización
sudo nft add rule inet filter input tcp dport 443 accept  # HTTPS
sudo nft add rule inet filter input tcp dport 7000 accept  # Cassandra comunicación interna
sudo nft add rule inet filter input tcp dport 7001 accept  # Cassandra comunicación cifrada
sudo nft add rule inet filter input tcp dport 9042 accept  # CQL (Cassandra)
sudo nft add rule inet filter input tcp dport 7199 accept  # JMX (Cassandra)

# Rechazar tráfico en el puerto Thrift (9160), ya que es obsoleto
sudo nft add rule inet filter input tcp dport 9160 reject

# Verificar las reglas
sudo nft list ruleset
