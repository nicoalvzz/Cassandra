from cassandra.cluster import Cluster

# Configuración de conexión
CASSANDRA_IP = "IP_DEL_SERVIDOR_CASSANDRA"  # IP del servidor Cassandra (modificada para seguridad)
CASSANDRA_PORT = 9042  # Puerto por defecto de Cassandra

def connect_and_list_keyspaces():
    try:
        # Conexión al clúster sin autenticación
        cluster = Cluster([CASSANDRA_IP], port=CASSANDRA_PORT)
        session = cluster.connect()

        # Mostrar la versión de Cassandra
        rows = session.execute('SELECT release_version FROM system.local')
        for row in rows:
            print(f"Cassandra version: {row.release_version}")

        print("\n--- Keyspaces en Cassandra ---")

        # Listar los keyspaces disponibles
        keyspaces = session.execute('SELECT keyspace_name FROM system_schema.keyspaces')
        for keyspace in keyspaces:
            print(f"- {keyspace.keyspace_name}")

        # Cerrar conexión
        cluster.shutdown()

    except Exception as e:
        print(f"Error al conectarse a Cassandra: {e}")

if __name__ == "__main__":
    connect_and_list_keyspaces()
