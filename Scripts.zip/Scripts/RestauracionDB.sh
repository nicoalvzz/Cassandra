#!/bin/bash

# Configuración de Cassandra
CASSANDRA_USER="usuario"  # Nombre de usuario de Cassandra (modificado para seguridad)
CASSANDRA_PASSWORD="contraseña"  # Contraseña de Cassandra (modificada para seguridad)
CASSANDRA_HOST="IP_DEL_SERVIDOR_CASSANDRA"  # IP del servidor Cassandra (modificada para seguridad)
KEYSPACE="mi_keyspace"
BACKUP_DIR="/BackupBD"
DATE="202501161749"
BACKUP_FILE="$BACKUP_DIR/$KEYSPACE-$DATE.cql"

# Restaurar el esquema
cqlsh $CASSANDRA_HOST -u $CASSANDRA_USER -p $CASSANDRA_PASSWORD -f $BACKUP_FILE

# Importar los datos de las tablas
TABLES=$(cqlsh $CASSANDRA_HOST -u $CASSANDRA_USER -p $CASSANDRA_PASSWORD -e "SELECT table_name FROM system_schema.tables WHERE keyspace_name='$KEYSPACE';" | awk 'NR>3 {print $1}')

for table in $TABLES; do
    if [ "$table" != "table_name" ] && [ "$table" != "" ]; then
        cqlsh $CASSANDRA_HOST -u $CASSANDRA_USER -p $CASSANDRA_PASSWORD -e "COPY $KEYSPACE.$table FROM '$BACKUP_DIR/$KEYSPACE-$table-$DATE.csv' WITH HEADER = TRUE;"
    fi
done

echo "Restauración completada."
