#!/bin/bash

# Configuración de Cassandra
CASSANDRA_USER="usuario"  # Nombre de usuario de Cassandra (modificado para seguridad)
CASSANDRA_PASSWORD="contraseña"  # Contraseña de Cassandra (modificada para seguridad)
CASSANDRA_HOST="IP_DEL_SERVIDOR_CASSANDRA"  # IP del servidor Cassandra (modificada para seguridad)
KEYSPACE="mi_keyspace"
BACKUP_DIR="/ruta/de/backup"
DATE=$(date +%Y%m%d%H%M)
BACKUP_FILE="$BACKUP_DIR/$KEYSPACE-$DATE.cql"

# Crear un archivo de backup
cqlsh $CASSANDRA_HOST -u $CASSANDRA_USER -p $CASSANDRA_PASSWORD -e "DESC KEYSPACE $KEYSPACE" > $BACKUP_FILE

# Exportar los datos de las tablas
TABLES=$(cqlsh $CASSANDRA_HOST -u $CASSANDRA_USER -p $CASSANDRA_PASSWORD -e "SELECT table_name FROM system_schema.tables WHERE keyspace_name='$KEYSPACE';")

for table in $TABLES; do
    if [ "$table" != "table_name" ]; then
        cqlsh $CASSANDRA_HOST -u $CASSANDRA_USER -p $CASSANDRA_PASSWORD -e "COPY $KEYSPACE.$table TO '$BACKUP_DIR/$KEYSPACE-$table-$DATE.csv' WITH HEADER = TRUE;"
    fi
done

# Eliminar copias de seguridad antiguas (más de 7 días)
find $BACKUP_DIR -type f -name "*.cql" -mtime +7 -exec rm {} \;
find $BACKUP_DIR -type f -name "*.csv" -mtime +7 -exec rm {} \;

echo "Copia de seguridad completada."
