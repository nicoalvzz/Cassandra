import cassandra
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
import time

# Configuración de acceso a Cassandra
CASSANDRA_USER = "usuario"  # Nombre de usuario de Cassandra (modificado para seguridad)
CASSANDRA_PASSWORD = "contraseña"  # Contraseña de Cassandra (modificada para seguridad)
SOURCE_CASSANDRA_HOST = "IP_DEL_SERVIDOR_ORIGEN"  # IP del servidor Cassandra de origen (modificada para seguridad)
SOURCE_CASSANDRA_PORT = 9042
DEST_CASSANDRA_HOST = "IP_DEL_SERVIDOR_DESTINO"  # IP del servidor Cassandra de destino (modificada para seguridad)
DEST_CASSANDRA_PORT = 9042
SOURCE_KEYSPACE = "mi_keyspace"  # Nombre del keyspace en Cassandra
DEST_KEYSPACE = "backup"  # Nombre del keyspace de destino

# Función para conectar a Cassandra
def connect_to_cassandra(host, port, user, password):
    try:
        auth_provider = PlainTextAuthProvider(username=user, password=password)
        cluster = Cluster([host], port=port, auth_provider=auth_provider)
        session = cluster.connect()
        return session
    except Exception as e:
        print(f"Error al conectar a Cassandra: {e}")
        return None

# Función para obtener todos los registros de una tabla
def get_all_records(session, keyspace, table):
    try:
        query = f"SELECT * FROM {keyspace}.{table}"
        result = session.execute(query)
        return result
    except Exception as e:
        print(f"Error al obtener datos de la tabla {table}: {e}")
        return []

# Función para crear el keyspace y la tabla de respaldo
def create_backup_table(session):
    try:
        session.execute(f"CREATE KEYSPACE IF NOT EXISTS {DEST_KEYSPACE} WITH replication = {{ 'class': 'SimpleStrategy', 'replication_factor': 1 }}")
        session.execute(f"CREATE TABLE IF NOT EXISTS {DEST_KEYSPACE}.usuarios_backup (id UUID PRIMARY KEY, nombre TEXT, email TEXT, edad INT)")
        print(f"Keyspace {DEST_KEYSPACE} y tabla usuarios_backup creados correctamente.")
    except Exception as e:
        print(f"Error al crear el keyspace o la tabla: {e}")

# Función para insertar registros en la base de datos de destino
def insert_records(session, keyspace, table, records):
    try:
        for record in records:
            columns = ", ".join(record._fields)
            values = ", ".join([f"'{value}'" if isinstance(value, str) else str(value) for value in record])
            query = f"INSERT INTO {keyspace}.{table} ({columns}) VALUES ({values})"
            session.execute(query)
        print(f"Registros insertados correctamente en la tabla {table}")
    except Exception as e:
        print(f"Error al insertar datos en la tabla {table}: {e}")

# Función principal para migrar datos
def migrate_data():
    print("Iniciando la migración de datos de Cassandra a Cassandra...")

    # Conectar a la base de datos de origen
    source_session = connect_to_cassandra(SOURCE_CASSANDRA_HOST, SOURCE_CASSANDRA_PORT, CASSANDRA_USER, CASSANDRA_PASSWORD)
    if not source_session:
        return

    # Conectar a la base de datos de destino
    dest_session = connect_to_cassandra(DEST_CASSANDRA_HOST, DEST_CASSANDRA_PORT, CASSANDRA_USER, CASSANDRA_PASSWORD)
    if not dest_session:
        return

    # Crear el keyspace y la tabla de respaldo
    create_backup_table(dest_session)

    # Obtener las tablas disponibles en el keyspace
    try:
        source_session.set_keyspace(SOURCE_KEYSPACE)
        tables_query = f"SELECT table_name FROM system_schema.tables WHERE keyspace_name='{SOURCE_KEYSPACE}'"
        tables = source_session.execute(tables_query)
        for table_row in tables:
            table = table_row.table_name
            print(f"Migrando tabla: {table}")

            # Obtener todos los registros de la tabla en la base de datos de origen
            records = get_all_records(source_session, SOURCE_KEYSPACE, table)

            if records:
                # Insertar los registros en la base de datos de destino
                insert_records(dest_session, DEST_KEYSPACE, f"{table}_backup", records)

    except Exception as e:
        print(f"Error al obtener las tablas o migrar datos: {e}")

    print("Migración completada.")

if __name__ == "__main__":
    migrate_data()
