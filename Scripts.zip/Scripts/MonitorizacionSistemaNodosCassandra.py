from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import Cluster
import psutil
import datetime
import requests

def generar_reporte():
    # Credenciales de Cassandra
    auth_provider = PlainTextAuthProvider(username='usuario', password='contraseña')  # Cambiado para seguridad

    # Conectar a Cassandra
    cluster = Cluster(['IP_DEL_SERVIDOR_CASSANDRA'], auth_provider=auth_provider)  # Cambiado para seguridad
    session = cluster.connect('system')

    # Obtener el estado de los nodos
    rows = session.execute("SELECT * FROM local")
    estado_nodos = ""
    for row in rows:
        # Cambiado el acceso a los valores por índices
        estado_nodos += f"Nodo {row[0]} - Estado: {row[1]}\n"

    # Obtener información del sistema
    cpu_percent = psutil.cpu_percent()
    memory_percent = psutil.virtual_memory().percent
    disk_usage = psutil.disk_usage('/').percent

    # Crear el reporte
    reporte = f"""
    Reporte de Cassandra - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    -------------------------------------------
    Uso de CPU: {cpu_percent}%
    Uso de Memoria: {memory_percent}%
    Uso de Disco: {disk_usage}%

    Estado de los Nodos en Cassandra:
    {estado_nodos}
    """

    # Enviar el reporte a Discord
    webhook_url = "URL_DEL_WEBHOOK_DE_DISCORD"  # Cambiado para seguridad
    data = {
        "content": reporte
    }

    try:
        response = requests.post(webhook_url, json=data)
        if response.status_code == 200 or response.status_code == 204:
            print("✅ Notificación enviada a Discord con éxito.")
        else:
            print(f"⚠️ Error al enviar notificación: {response.status_code}")
    except Exception as e:
        print(f"❌ Error al intentar enviar la notificación: {e}")

    # Guardar el reporte en un archivo
    with open(f"reporte_{datetime.datetime.now().strftime('%Y%m%d')}.txt", 'w') as file:
        file.write(reporte)

    print("Reporte generado con éxito.")

if __name__ == "__main__":
    generar_reporte()
