from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

# Configuración de acceso a Cassandra
CASSANDRA_USER = "usuario"  # Nombre de usuario de Cassandra (modificado para seguridad)
CASSANDRA_PASSWORD = "contraseña"  # Contraseña de Cassandra (modificada para seguridad)
CASSANDRA_HOST = "IP_DEL_SERVIDOR_CASSANDRA"  # IP del servidor Cassandra (modificada para seguridad)
KEYSPACE = "mi_keyspace"

# Conectar a Cassandra
auth_provider = PlainTextAuthProvider(username=CASSANDRA_USER, password=CASSANDRA_PASSWORD)
cluster = Cluster([CASSANDRA_HOST], auth_provider=auth_provider)
session = cluster.connect()

# Obtener la lista de tablas
query_tables = f"SELECT table_name FROM system_schema.tables WHERE keyspace_name='{KEYSPACE}'"
tables = session.execute(query_tables)

# Guardar resultados en un archivo
with open('inventario.txt', 'w') as f:
    for table in tables:
        table_name = table.table_name
        f.write(f'Tabla: {table_name}\n')

        # Obtener detalles de las columnas
        query_columns = f"SELECT column_name, type FROM system_schema.columns WHERE keyspace_name='{KEYSPACE}' AND table_name='{table_name}'"
        columns = session.execute(query_columns)
        f.write("  Columnas:\n")
        for column in columns:
            f.write(f"    - {column.column_name} ({column.type})\n")

        # Contar el número de filas
        query_count = f"SELECT COUNT(*) FROM {KEYSPACE}.{table_name}"
        count = session.execute(query_count).one()[0]
        f.write(f"  Número de filas: {count}\n\n")

print("Inventario completado.")

